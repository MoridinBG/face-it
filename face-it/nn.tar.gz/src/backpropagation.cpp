/***************************************************************************
 *   Copyright (C) 2008 by Ivan Dilchovski   *
 *   root.darkstar@gmail.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "backpropagation.h"

/**
 * Dummy constructor. Creates an empty Backpropagation object.
 */
Backpropagation::Backpropagation ()
{
}

Backpropagation::~Backpropagation()
{
}

/**
 * Overloaded function provided for loading more than one input/target pair
 * @param _inputs Vector of input vectors 
 * @param _targets Vector of target vectors
 * @param _learningRate Rate for changing the weights. Higher values would provide faster, but less accurate teaching, smaller for slower and more accurate one.0.2 is a common value.
 * @param _momentum Used to provide momentum to the teaching. Uses part of the previous change in the weights. 0.8 is common value.t
 */
void Backpropagation::loadParameters(	std::vector<std::vector<double> > _inputs,
					std::vector<std::vector<double> > _targets,
     					std::vector<std::vector<double> > _untrainedInputs,
     					std::vector<std::vector<double> > _untrainedTargets,
     					double _learningRate,
     					double _momentum)
{

	if (_inputs.size() != _targets.size())
		throw Exception("[BACKPROPAGATION] Number of targets must equal number of inputs.");

	if (_untrainedInputs.size() != _untrainedTargets.size())
		throw Exception("[BACKPROPAGATION] Number of targets must equal number of inputs.");
		
	for(unsigned int i = 0; i < _targets.size(); ++i)
		if(!checkTargets(_targets[i]))
			throw Exception("[BACKPROPAGATION] Incorrect target vector fed.");

	for(unsigned int i = 0; i < _untrainedTargets.size(); ++i)
		if(!checkTargets(_untrainedTargets[i]))
			throw Exception("[BACKPROPAGATION] Incorrect untrained target vector fed.");
	
	targets = _targets;
	inputs = _inputs;

	untrainedInputs = _untrainedInputs;
	untrainedTargets = _untrainedTargets;
	
	momentum = _momentum;
	learningRate = _learningRate;
}
/**
 * Performs the backpropagation,
 * @param _network Network on which to perform backpropagation
 * @param iterations Number of iterations to perform
 * @return True for successful backpropagation, otherwise false.
 */
void Backpropagation::backpropagate()
{
	//Clear all vectors from previous iterrations
	actual.clear();
	outputErrorSignals.clear();
	networkLayers.clear();
	hiddenLayers.clear();

	//Pick up a random pair of Input and Targeted output
	int lotary = rand() % inputs.size();
	target = targets[lotary];
	input = inputs[lotary];

	//Calculate the output of the layer for this input
	network->calculateOutput(input);
	actual = network->getOutput();

	//Calculate the error of the network and make a small adjustement to the weights of the neurons.
	calculateErrorSignals();
	changeWeights();
}

/**
 * Checks if expected values are in the 0 to 1 range.
 * @param target Target vector
 * @return True for correct target vector, otherwise false.
 */
bool Backpropagation::checkTargets(std::vector<double>& target)
{
	for (unsigned int i = 0; i < target.size(); ++i)
		if ((target[i] < 0) || (target[i] > 1))
			return false;

	return true;
}

/**
 * Calculates the error caused by wrong weight values
 */
void Backpropagation::calculateErrorSignals()
{
	std::vector<Neuron*> neuronsAtCurrentLayer;
	std::vector<Neuron*> neuronsAtUpperLayer;
	std::vector<Layer*> ::iterator itLayer;
	Layer *currentLayer;
	Layer *upperLayer;

	//Calculate the error signal of the output layer
	for(unsigned int i = 0; i < actual.size(); i++)
	{
		double errorSignal = actual[i] * ((1 - actual[i]) * (target[i] - actual[i]));
		outputErrorSignals.push_back(errorSignal);
	}
	network->getOutputLayer()->setErrorSignal(outputErrorSignals);

	//Load the input layer
	networkLayers.push_back(network->getInputLayer());
	//Load the hidden layers
	hiddenLayers = network->getHiddenLayers();
	for(itLayer = hiddenLayers.begin(); itLayer < hiddenLayers.end(); itLayer++)
		networkLayers.push_back(*itLayer);
	//Load the output layer
	networkLayers.push_back(network->getOutputLayer());

	//Calculate the error form the last hidden to the input layer
	for(int i = (networkLayers.size() - 2); i >= 0; --i)
	{
		currentLayer = networkLayers[i];
		upperLayer = networkLayers[i + 1];
		neuronsAtCurrentLayer = currentLayer->getNeurons();
		neuronsAtUpperLayer = upperLayer->getNeurons();
		std::vector<double> currentErrorSignals;
		//Calculate the error for every single neuron at the current layer
		for (unsigned int j = 0; j < neuronsAtCurrentLayer.size(); ++j)
		{
			double sum = 0;
			double currentErrorSignal;
			double currentOutput = neuronsAtCurrentLayer[j]->getOutput();
			double upperErrorSignal;
			double weight;
			//Calculate the contribution to the error of every neuron at the upper layer
			for (unsigned int k = 0; k < neuronsAtUpperLayer.size() ; ++k)
			{
				upperErrorSignal = upperLayer->getErrorSignal()[k];
				weight = neuronsAtUpperLayer[k]->getWeights()[j];

				sum += upperErrorSignal * weight;
			}

			currentErrorSignal = currentOutput * (1.0 - currentOutput) * sum;
			currentErrorSignals.push_back(currentErrorSignal);
		}
		//Store the error signals from this iterration
		networkLayers[i]->setErrorSignal(currentErrorSignals);

	}
}

/**
 * Makes corrections on the weights according to the error they cause.
 */
void Backpropagation::changeWeights()
{
	std::vector<Neuron*> neuronsAtCurrentLayer;
	std::vector<Neuron*> neuronsAtLowerLayer;
	std::vector<double> levelErrorSignals;
	std::vector<double> weights;
	std::vector<double> newWeights;
	std::vector<double> weightChanges;
	std::vector<double> newWeightChanges;
	
	double input;
	double previousDelta;
	double errorSignal;
	double weightDelta;
	double newWeight;

	//Iterrate from the output layer to the first input layer
	for(unsigned int i = (networkLayers.size() - 1); i > 0; --i)
	{
		neuronsAtCurrentLayer = networkLayers[i]->getNeurons();
		neuronsAtLowerLayer = networkLayers[i - 1]->getNeurons();
		levelErrorSignals = networkLayers[i]->getErrorSignal();
		//Iterrate all error signals (In fact all neurons at this layer)
		for (unsigned int j = 0; j < levelErrorSignals.size(); ++j)
		{
			weights = neuronsAtCurrentLayer[j]->getWeights();
			weightChanges = neuronsAtCurrentLayer[j]->getWeightChanges();
			//Adjust all the weights of connection to the previous layer, according to the error
			for (unsigned int k = 0; k < neuronsAtLowerLayer.size(); ++k)
			{
				input = neuronsAtLowerLayer[k]->getOutput();
				previousDelta = weightChanges[k];
				errorSignal = levelErrorSignals[j];
				if(isnan(errorSignal))
 					cout << "errorSignal" << endl;
				if(isnan(input))
					cout << "input" << endl;
				if(isnan(previousDelta))
					cout << "previousDelta" << endl;
				//Adjustment is made by taking into account the input  and the previous weight change
				weightDelta = ((learningRate * errorSignal * input) + (momentum * previousDelta));
				newWeight = weights[k] + weightDelta;
				newWeights.push_back(newWeight);
				newWeightChanges.push_back(weightDelta);

			}
			//Set new weights and weight changes
			neuronsAtCurrentLayer[j]->setWeightChanges(newWeightChanges);
			neuronsAtCurrentLayer[j]->setWeights(newWeights);
			newWeightChanges.clear();
			newWeights.clear();
		}
	}
}

void Backpropagation::appendTrainedParameters(std::vector< std::vector < double > > _inputs,
					      std::vector< std::vector < double > > _targets)
{
	if(_inputs.size() != _targets.size())
		throw Exception("[BACKPROPAGATION] Mismatching number of inputs and targets provided.");
	
	inputs.insert(inputs.begin(),_inputs.begin(),_inputs.end());
	targets.insert(targets.begin(),_targets.begin(),_targets.end());
}

void Backpropagation::appendUntrainedParameters(std::vector< std::vector < double > > _untrainedInputs,
		 				std::vector< std::vector < double > > _untrainedTargets)
{
	if(_untrainedInputs.size() != _untrainedTargets.size())
		throw Exception("[BACKPROPAGATION] Mismatching number of untrained inputs and untrained targets provided.");

	untrainedInputs.insert(untrainedInputs.begin(),_untrainedInputs.begin(),_untrainedInputs.end());
	untrainedTargets.insert(untrainedTargets.begin(),_untrainedTargets.begin(),_untrainedTargets.end());
}



/*!
    \fn Backpropagation::start()
 */
void Backpropagation::start(Network* _network, unsigned int iterations)
{
	checkData(_network);
	
	network = _network;
	for(unsigned int i; i < iterations; ++i)
		backpropagate();
}


/*!
    \fn Backpropagation::checkData()
 */
void Backpropagation::checkData(Network* _network)
{
	if(_network == 0)
		throw Exception("[BACKPROPAGATION] Null network provided for training.");
	
	if((inputs.size() == 0) || (targets.size() == 0) || (learningRate == 0))
		throw Exception("[BACKPROPAGATION] Learning parameters not correctly set.");

	for(unsigned int i = 0; i < inputs.size(); ++i)
		if(inputs[i].size() != _network->getInputSize())
		{
			throw Exception("[BACKPROPAGATION] An input vector unsuitable for this network provided.");
		}

	for(unsigned int i = 0; i < untrainedInputs.size(); ++i)
		if(untrainedInputs[i].size() != _network->getInputSize())
		{
			throw Exception("[BACKPROPAGATION] An untrained input vector unsuitable for this network provided.");
		}

	if(momentum == 0)
		std::cout << "WARNING: Momentum is 0. This may slow down training." << endl;
}


/*!
    \fn Backpropagation::start(Network* _network, double error)
 */
void Backpropagation::start(Network* _network, double error)
{
	checkData(_network);
	network = _network;

	do
	{
		for(unsigned int i = 0; i < UNCHECKED_BACKPROPAGATIONS; ++i)
			backpropagate();
	} while(calculateError() > error);
}


/*!
    \fn Backpropagation::calculateError()
 */
double Backpropagation::calculateError()
{
	double error = 0;
	
    	for(unsigned int i = 0; i < untrainedInputs.size(); ++i)
    	{
		network->calculateOutput(untrainedInputs[i]);
		error += (network->getOutput()[0] - untrainedTargets[i][0]) * (network->getOutput()[0] - untrainedTargets[i][0]);
		//cout << "Value: " << network->getOutput()[0] << " Target: " << untrainedTargets[i][0] << endl;
    	}

	error = error / untrainedInputs.size();
	std::cout << "Error : " << error << endl;
	return error;
	
}

