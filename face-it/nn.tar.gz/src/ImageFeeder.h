#ifndef IMAGEFEEDER_H_
#define IMAGEFEEDER_H_

#include <QImage>
#include "exception.h"
class ImageFeeder
{
public:
	~ImageFeeder();
	ImageFeeder(int _width, int _height);
	void loadImage(QImage *_image);
	void loadImage(char* path);
	
	QImage *scaleDown();
	QImage *getImage();
	void createInputsFromImage(std::vector<std::vector<double> >& inputs);
private:
	QImage *image;

	int width;
	int height;
};

#endif /*IMAGEFEEDER_H_*/
