PictureBasket::PictureBasket()
{
	size = 0;
}