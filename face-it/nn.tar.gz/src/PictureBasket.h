class PictureBasket
{
public:
	PictureBasket();
	~PictureBasket();
	void insert(QImage* newImage);
private:
	unsigned int size;
};